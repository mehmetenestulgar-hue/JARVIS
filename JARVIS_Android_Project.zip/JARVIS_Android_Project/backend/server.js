const express = require("express");

const app = express();
app.use(express.json({ limit: "1mb" }));

const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4.1-mini";

app.get("/health", (_req, res) => res.json({ ok: true, service: "JARVIS" }));

app.post("/api/chat", async (req, res) => {
  try {
    if (!API_KEY) return res.status(500).json({ error: "Sunucuda OPENAI_API_KEY tanımlı değil." });

    const messages = Array.isArray(req.body.messages) ? req.body.messages : [];
    const safeMessages = messages.slice(-30).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 8000)
    }));

    const input = safeMessages.map(m => ({
      role: m.role,
      content: [{ type: "input_text", text: m.content }]
    }));

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        instructions: "Sen JARVIS adlı Türkçe konuşan, ciddi, güvenilir ve yetenekli bir kişisel yapay zekâ asistanısın. Net ve doğru cevap ver. Bilmediğin şeyi uydurma. Telefon işlemlerini gerçekten yaptığını iddia etme; Android uygulamasının sunduğu araçlarla yapılabilecekleri açıkla.",
        input
      })
    });

    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "OpenAI API hatası." });

    let reply = data.output_text || "";
    if (!reply && Array.isArray(data.output)) {
      for (const item of data.output) {
        for (const part of (item.content || [])) {
          if (part.type === "output_text") reply += part.text;
        }
      }
    }
    res.json({ reply: reply || "Yanıt üretilemedi." });
  } catch (err) {
    res.status(500).json({ error: "Sunucu hatası: " + err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`JARVIS backend listening on ${port}`));
