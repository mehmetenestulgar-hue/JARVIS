JARVIS ANDROID - KURULUM

Bu paket Android uygulamasının kaynak kodunu ve OpenAI API bağlantısı için backend örneğini içerir. Hazır APK değildir.

1) ANDROID PROJESİ
- AIDE'de veya Android Studio'da mevcut Gradle projesini aç.
- Proje kökündeki dosyaları kullan.
- Derleme tamamlanınca uygulamayı telefona yükle.
- İlk mikrofon kullanımında izin ver.

2) GERÇEK YAPAY ZEKA BAĞLANTISI
Uygulama doğrudan OpenAI anahtarını içermez. Güvenlik için backend sunucusu gerekir.
- backend klasörünü Node.js destekleyen bir HTTPS sunucusuna yükle.
- Sunucuda OPENAI_API_KEY ortam değişkenini tanımla.
- İsteğe bağlı OPENAI_MODEL değişkeni: gpt-4.1-mini
- npm install
- npm start
- Sunucunun HTTPS adresini kontrol et: https://SUNUCU-ADRESIN/health
- MainActivity.java içindeki API_URL değerini https://SUNUCU-ADRESIN/api/chat olarak değiştir.
- Uygulamayı yeniden derle.

ÖNEMLİ:
- API anahtarını APK'ya, Java dosyasına veya herkese açık depoya koyma.
- API kullanımı ücretlidir; ChatGPT aboneliği API kredisi değildir.
- Sunucuya kimlik doğrulama, hız sınırı ve kötüye kullanım koruması eklemeden herkese açık dağıtma.
- Ses tanıma Android'in cihazdaki konuşma tanıma hizmetini kullanır; çevrimdışı çalışması telefondaki dil paketine bağlıdır.
- Bu başlangıç sürümünde sohbet, geçmiş, Türkçe konuşma tanıma/yanıt, saat, ayarlar, kamera, YouTube ve WhatsApp kısayolları bulunur.
- Web araması, görsel yükleme/analizi, gelişmiş cihaz kontrolü, alarm yönetimi ve arka plan uyandırma sonraki geliştirme modülleridir; bu sürümde tamamlanmış özellikler değildir.

GEREKSİNİMLER
- Android SDK 33 veya uyumlu derleme ortamı
- Minimum Android 6.0 (API 23)
- Node.js 18+ (backend için)
